package com.cg.service;



import java.util.List;

import com.cg.bean.Discount;
import com.cg.bean.HotelOwner;
import com.cg.bean.Hotel;

import com.cg.bean.Promocode;
import com.cg.bean.User1;







public interface AdminServices {
	
	//---------------------------------------------Discount-----------------------------------------------------
	public Discount addDiscount(Discount discount); 
	public void removeDiscount(int discountId);
	public Discount findDiscount(int discountId);
	public List<Discount> AllDiscounts();
	public void updateDiscount(Discount discount);
	//-----------------------------------------------------------------------------------------------------------
	
	//-----------------------------------User------------------------------------------------------------------------
	public List<User1> AllUsers();
	public void removeUser(int userId);
	//-----------------------------------------------------------------------------------------------------------
	
	//------------------------------------------------Merchant----------------------------------------------------------
	public List<Merchant> AllHotelOwners();
	public void removeHotelOwner(int hotelOwnerId);
	//-----------------------------------------------------------------------------------------------------------
		
		
	//----------------------------------------------------Product-------------------------------------------------------
	public List<Product> AllHotels();
	public void removeHotel(int hotelId);
	public Product findHotel(int hotelId);
	//-----------------------------------------------------------------------------------------------------------
		
	//-----------------------------------------------------PromoCode---------------------------------------------
	
	public void addPromo(Promocode promo);
	public void deletePromo(int id);
	public List<Promocode> getAllPromos();

	//------------------------------------------------------------------------------------
	
}
