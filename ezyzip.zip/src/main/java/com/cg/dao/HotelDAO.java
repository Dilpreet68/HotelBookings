package com.cg.dao;

import java.util.List;

import org.jboss.logging.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.bean.Hotel;

public interface HotelDAO extends JpaRepository<Hotel, Integer>{
	

}
