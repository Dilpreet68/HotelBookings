package com.cg.bean;

import java.sql.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="Hotel")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Hotel {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private Integer HotelID;
	
	@Column
	private String HotelName;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="HotelOwner.HotelOwnerId")
	private HotelOwner hotelowner;
	
	@Column
	private String photo;
	
	@Column 
	private String description;
	
	@Column
	private Integer price;
	
	
	private Date bookingDate;
	
	public Hotel() {
		// TODO Auto-generated constructor stub
	}





	public Hotel(String HotelName, HotelOwner hotelowner, String photo,
			String description, Integer price, Date bookingDate) {
		super();
		this.HotelName = HotelName;
		this.hotelowner = hotelowner;
		this.photo = photo;
		this.description = description;
		this.price = price;
		this.bookingDate = bookingDate;
	}


	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getHotelID() {
		return HotelID;
	}

	public void setHotelID(Integer productID) {
		this.HotelID = HotelID;
	}

	public String getHotelName() {
		return HotelName;
	}

	public void HotelName(String HotelName) {
		this.HotelName = HotelName;
	}

	public HotelOwner hotelowner() {
		return hotelowner;
	}
	
	public void setMerchant(HotelOwner hotelowner) {
		this.hotelowner = hotelowner;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	public Date getBookingDate() {
		return bookingDate;
	}
	
	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}
	
}
